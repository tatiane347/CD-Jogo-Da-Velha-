
FREE APP

Created by WebIntoApp.com on Monday 9th of September 2024 12:27:34 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			431110
App Key:		GhfIGUrjruUiAMbcwGUcyZzKEKnkRhAo
App Name:		Jogo Da Velha
App Version:	1.0
Package:		com.mycompany.jogodavelha
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://www.webintoapp.com/author/apps/431110/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://www.webintoapp.com/author/apps

Get installs statistics at:
https://www.webintoapp.com/author/stats?appid=431110

The Author Area:
https://www.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
